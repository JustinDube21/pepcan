/* ============================================
   PEPTIDES CANADA - THEME JAVASCRIPT
   Cart, Navigation, Animations, UX
   ============================================ */

(function() {
  'use strict';

  /* ---------- Age Gate ---------- */
  const ageGate = {
    init() {
      const modal = document.getElementById('ageGateModal');
      if (!modal) return;
      const confirmed = sessionStorage.getItem('pc_research_confirmed');
      if (confirmed) {
        document.body.classList.remove('pc-age-gate-active');
        modal.remove();
        return;
      }
      modal.classList.add('active');
      document.body.classList.add('pc-age-gate-active');
      document.body.style.overflow = 'hidden';

      document.getElementById('ageGateConfirm')?.addEventListener('click', () => {
        sessionStorage.setItem('pc_research_confirmed', 'true');
        modal.classList.remove('active');
        document.body.classList.remove('pc-age-gate-active');
        document.body.style.overflow = '';
        setTimeout(() => modal.remove(), 500);
      });

      document.getElementById('ageGateDeny')?.addEventListener('click', () => {
        window.location.href = 'https://www.google.com';
      });
    }
  };

  /* ---------- Header Scroll ---------- */
  const header = {
    init() {
      const el = document.querySelector('.site-header');
      if (!el) return;
      let ticking = false;
      window.addEventListener('scroll', () => {
        if (!ticking) {
          window.requestAnimationFrame(() => {
            el.classList.toggle('scrolled', window.scrollY > 50);
            ticking = false;
          });
          ticking = true;
        }
      });
    }
  };

  /* ---------- Mobile Menu ---------- */
  const mobileMenu = {
    init() {
      const toggle = document.getElementById('mobileMenuToggle');
      const menu = document.getElementById('mobileMenu');
      const overlay = document.getElementById('mobileMenuOverlay');
      const close = document.getElementById('mobileMenuClose');
      if (!toggle || !menu) return;

      const isOpen = () => menu.classList.contains('active');
      const open = () => {
        menu.classList.add('active');
        overlay?.classList.add('active');
        toggle.classList.add('active');
        toggle.setAttribute('aria-expanded', 'true');
        toggle.setAttribute('aria-label', 'Close menu');
        document.body.style.overflow = 'hidden';
      };
      const shut = () => {
        menu.classList.remove('active');
        overlay?.classList.remove('active');
        toggle.classList.remove('active');
        toggle.setAttribute('aria-expanded', 'false');
        toggle.setAttribute('aria-label', 'Open menu');
        document.body.style.overflow = '';
      };

      toggle.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        if (isOpen()) {
          shut();
        } else {
          open();
        }
      });
      close?.addEventListener('click', shut);
      overlay?.addEventListener('click', shut);
      menu.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', shut);
      });
      document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && isOpen()) shut();
      });
    }
  };

  /* ---------- Shop Mega Menu ---------- */
  const shopMegaMenu = {
    init() {
      const trigger = document.querySelector('.pc-shop-trigger');
      const menu = trigger?.querySelector('.pc-shop-mega');
      const link = trigger?.querySelector('a');
      if (!trigger || !menu) return;

      let closeTimer;
      let overlayTicking = false;
      const closeDelay = 380;

      const syncOverlayTop = () => {
        const siteHeader = document.querySelector('.site-header');
        if (!siteHeader) return;
        const headerBottom = Math.max(0, Math.round(siteHeader.getBoundingClientRect().bottom));
        document.documentElement.style.setProperty('--pc-header-overlay-top', `${headerBottom}px`);
      };

      const requestOverlaySync = () => {
        if (overlayTicking) return;
        overlayTicking = true;
        window.requestAnimationFrame(() => {
          syncOverlayTop();
          overlayTicking = false;
        });
      };

      const isInsideMenuArea = () => (
        trigger.matches(':hover') ||
        menu.matches(':hover') ||
        trigger.matches(':focus-within')
      );

      const open = () => {
        syncOverlayTop();
        window.clearTimeout(closeTimer);
        trigger.classList.add('is-open');
        link?.setAttribute('aria-expanded', 'true');
      };

      const close = () => {
        trigger.classList.remove('is-open');
        link?.setAttribute('aria-expanded', 'false');
      };

      const scheduleClose = () => {
        window.clearTimeout(closeTimer);
        closeTimer = window.setTimeout(() => {
          if (!isInsideMenuArea()) {
            close();
          }
        }, closeDelay);
      };

      syncOverlayTop();
      link?.setAttribute('aria-haspopup', 'true');
      link?.setAttribute('aria-expanded', 'false');

      trigger.addEventListener('pointerenter', open);
      trigger.addEventListener('pointerleave', scheduleClose);
      menu.addEventListener('pointerenter', open);
      menu.addEventListener('pointerleave', scheduleClose);
      trigger.addEventListener('focusin', open);
      trigger.addEventListener('focusout', () => {
        window.setTimeout(() => {
          if (!trigger.contains(document.activeElement)) close();
        }, 0);
      });
      window.addEventListener('resize', requestOverlaySync);
      window.addEventListener('scroll', requestOverlaySync, { passive: true });

      document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') close();
      });
    }
  };

  /* ---------- Cart Drawer ---------- */
  const cartDrawer = {
    init() {
      const drawer = document.getElementById('cartDrawer');
      const overlay = document.getElementById('cartDrawerOverlay');
      const closeBtn = document.getElementById('cartDrawerClose');
      if (!drawer) return;

      document.querySelectorAll('[data-cart-toggle]').forEach(btn => {
        btn.addEventListener('click', (e) => {
          e.preventDefault();
          this.open();
        });
      });
      closeBtn?.addEventListener('click', () => this.close());
      overlay?.addEventListener('click', () => this.close());
    },
    open() {
      document.getElementById('cartDrawer')?.classList.add('active');
      document.getElementById('cartDrawerOverlay')?.classList.add('active');
      document.body.style.overflow = 'hidden';
    },
    close() {
      document.getElementById('cartDrawer')?.classList.remove('active');
      document.getElementById('cartDrawerOverlay')?.classList.remove('active');
      document.body.style.overflow = '';
    }
  };

  /* ---------- Add to Cart (AJAX) ---------- */
  const cart = {
    init() {
      document.addEventListener('click', (e) => {
        const btn = e.target.closest('[data-add-to-cart]');
        if (!btn) return;
        e.preventDefault();
        const form = btn.closest('form');
        const variantInput = form?.querySelector('input[name="id"]');
        const quantityInput = form?.querySelector('input[name="quantity"]');
        const variantId = variantInput?.value || btn.dataset.variantId;
        const qty = quantityInput?.value || btn.dataset.qty || 1;
        if (!variantId) return;
        btn.dataset.variantId = variantId;
        this.addItem(variantId, qty, btn);
      });
    },
    async addItem(variantId, quantity, btn) {
      const originalText = btn.innerHTML;
      btn.innerHTML = '<span class="btn-spinner"></span> Adding...';
      btn.disabled = true;
      try {
        const res = await fetch(window.PeptidesCanada?.cart_add_url || '/cart/add.js', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ items: [{ id: parseInt(variantId), quantity: parseInt(quantity) }] })
        });
        if (!res.ok) throw new Error('Failed to add');
        await this.refreshCart();
        cartDrawer.open();
      } catch (err) {
        console.error(err);
        btn.innerHTML = 'Error - Try Again';
        setTimeout(() => { btn.innerHTML = originalText; }, 2000);
      } finally {
        btn.disabled = false;
        if (!btn.innerHTML.includes('Error')) btn.innerHTML = originalText;
      }
    },
    async refreshCart() {
      try {
        const res = await fetch('/cart.js', { headers: { 'Accept': 'application/json' } });
        const data = await res.json();
        // Update cart count badges
        document.querySelectorAll('.cart-count').forEach(el => {
          el.textContent = data.item_count || '';
        });
        // Update complimentary shipping progress
        const threshold = parseInt(window.PeptidesCanada?.free_shipping_threshold || 24999);
        const pct = Math.min((data.total_price / threshold) * 100, 100);
        document.querySelectorAll('.shipping-progress-fill').forEach(el => {
          el.style.width = pct + '%';
        });
      } catch (err) {
        console.error('Cart refresh error', err);
      }
    }
  };

  /* ---------- Product Page ---------- */
  const productPage = {
    formatMoney(cents) {
      if (window.Shopify && typeof window.Shopify.formatMoney === 'function') {
        return window.Shopify.formatMoney(cents, window.PeptidesCanada?.money_format);
      }

      const amount = (Number(cents) || 0) / 100;
      try {
        return new Intl.NumberFormat(document.documentElement.lang || 'en-CA', {
          style: 'currency',
          currency: window.Shopify?.currency?.active || 'CAD'
        }).format(amount);
      } catch (e) {
        return `$${amount.toFixed(2)}`;
      }
    },
    getSelectedOptions(picker) {
      return Array.from(picker.querySelectorAll('[data-option-group]')).map(group => {
        const activeButton = group.querySelector('.filter-btn.active');
        return activeButton?.dataset.optionValue || null;
      });
    },
    findVariant(variants, selectedOptions) {
      return variants.find(variant => {
        if (!Array.isArray(variant.options)) return false;
        return variant.options.every((optionValue, index) => optionValue === selectedOptions[index]);
      });
    },
    syncVariantState(productRoot) {
      const variantsJson = productRoot.querySelector('[data-product-variants-json]');
      const picker = productRoot.querySelector('[data-variant-picker]');
      const variantIdInput = productRoot.querySelector('[data-variant-id-input]');
      const addToCartBtn = productRoot.querySelector('[data-add-to-cart]');
      const addToCartText = productRoot.querySelector('[data-add-to-cart-text]');
      const priceEl = productRoot.querySelector('[data-product-price]');
      const comparePriceEl = productRoot.querySelector('[data-product-compare-price]');
      const saveEl = productRoot.querySelector('[data-product-save]');
      if (!variantsJson || !variantIdInput || !addToCartBtn || !priceEl) return;

      let variants = [];
      try {
        variants = JSON.parse(variantsJson.textContent || '[]');
      } catch (e) {
        console.error('Invalid product variants JSON', e);
        return;
      }

      const selectedOptions = picker ? this.getSelectedOptions(picker) : [];
      const variant = picker ? this.findVariant(variants, selectedOptions) : variants.find(v => String(v.id) === String(variantIdInput.value)) || variants[0];
      if (!variant) return;

      variantIdInput.value = variant.id;
      addToCartBtn.dataset.variantId = variant.id;

      priceEl.textContent = this.formatMoney(variant.price);

      if (comparePriceEl && saveEl) {
        if (variant.compare_at_price && variant.compare_at_price > variant.price) {
          comparePriceEl.textContent = this.formatMoney(variant.compare_at_price);
          saveEl.textContent = `Save ${this.formatMoney(variant.compare_at_price - variant.price)}`;
          comparePriceEl.hidden = false;
          saveEl.hidden = false;
        } else {
          comparePriceEl.hidden = true;
          saveEl.hidden = true;
        }
      }

      if (variant.available) {
        addToCartBtn.disabled = false;
        addToCartBtn.innerHTML = `Add to Cart &mdash; ${this.formatMoney(variant.price)}`;
      } else {
        addToCartBtn.disabled = true;
        addToCartBtn.textContent = 'Sold Out';
      }
    },
    init() {
      // Quantity buttons
      document.querySelectorAll('.qty-minus').forEach(btn => {
        btn.addEventListener('click', () => {
          const input = btn.parentElement.querySelector('input');
          if (input && parseInt(input.value) > 1) input.value = parseInt(input.value) - 1;
        });
      });
      document.querySelectorAll('.qty-plus').forEach(btn => {
        btn.addEventListener('click', () => {
          const input = btn.parentElement.querySelector('input');
          if (input) input.value = parseInt(input.value) + 1;
        });
      });

      // Variant picker
      document.querySelectorAll('.product-page').forEach(productRoot => {
        const picker = productRoot.querySelector('[data-variant-picker]');
        if (picker) {
          picker.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', () => {
              const group = btn.closest('[data-option-group]');
              if (!group) return;
              group.querySelectorAll('.filter-btn').forEach(optionBtn => {
                optionBtn.classList.remove('active');
                optionBtn.setAttribute('aria-pressed', 'false');
              });
              btn.classList.add('active');
              btn.setAttribute('aria-pressed', 'true');
              this.syncVariantState(productRoot);
            });
          });
        }
        this.syncVariantState(productRoot);
      });

      // Tabs
      document.querySelectorAll('.product-tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const target = btn.dataset.tab;
          document.querySelectorAll('.product-tab-btn').forEach(b => b.classList.remove('active'));
          document.querySelectorAll('.product-tab-content').forEach(c => c.classList.remove('active'));
          btn.classList.add('active');
          document.getElementById(target)?.classList.add('active');
        });
      });

      // Image thumbnails
      document.querySelectorAll('.product-thumbnail').forEach(thumb => {
        thumb.addEventListener('click', () => {
          const src = thumb.querySelector('img')?.src;
          const mainImg = document.querySelector('.product-main-image img');
          if (src && mainImg) mainImg.src = src;
          document.querySelectorAll('.product-thumbnail').forEach(t => t.classList.remove('active'));
          thumb.classList.add('active');
        });
      });
    }
  };

  /* ---------- FAQ Accordion ---------- */
  const faq = {
    init() {
      document.querySelectorAll('.faq-question').forEach(btn => {
        btn.addEventListener('click', () => {
          const item = btn.parentElement;
          const answer = item.querySelector('.faq-answer');
          const isActive = item.classList.contains('active');

          // Close all
          document.querySelectorAll('.faq-item').forEach(i => {
            i.classList.remove('active');
            i.querySelector('.faq-answer').style.maxHeight = '0';
          });

          if (!isActive && answer) {
            item.classList.add('active');
            answer.style.maxHeight = answer.scrollHeight + 'px';
          }
        });
      });
    }
  };

  /* ---------- Legal Disclaimer ---------- */
  

  /* ---------- Scroll Animations ---------- */
  const animations = {
    init() {
      const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            observer.unobserve(entry.target);
          }
        });
      }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });

      document.querySelectorAll('.fade-in').forEach(el => observer.observe(el));
    }
  };

  /* ---------- Init ---------- */
  document.addEventListener('DOMContentLoaded', () => {
    ageGate.init();
    header.init();
    shopMegaMenu.init();
    mobileMenu.init();
    cartDrawer.init();
    cart.init();
    productPage.init();
    faq.init();
    animations.init();
  });
})();
document.addEventListener("DOMContentLoaded", function () {
  const searchWrapper = document.getElementById("headerSearch");
  const searchToggle = document.getElementById("predictiveSearchToggle");
  const input = document.getElementById("predictive-search-input");
  const resultsBox = document.getElementById("predictive-search-results");

  if (!searchWrapper || !searchToggle || !input || !resultsBox) return;

  let debounceTimer;
  const popularSearches = ['Retatrutide', 'GHK-CU', 'Tesamorelin', 'BPC-157', 'CJC-1295', 'Tirzepatide'];

  function showPopularSearches() {
    resultsBox.innerHTML = ''
      + '<div class="predictive-search-dropdown predictive-search-popular">'
      + '<div class="predictive-search-panel-head"><span>Popular Searches</span><small>High-demand research products</small></div>'
      + '<div class="predictive-search-popular-grid">'
      + popularSearches.map(function (term) {
        return '<a href="/search?q=' + encodeURIComponent(term) + '&type=product">' + term + '</a>';
      }).join('')
      + '</div></div>';
    resultsBox.classList.add("active");
  }

  searchToggle.addEventListener("click", function (e) {
    e.preventDefault();

    searchWrapper.classList.toggle("active");

    if (searchWrapper.classList.contains("active")) {
      setTimeout(() => input.focus(), 50);
      if (input.value.trim().length < 1) showPopularSearches();
    } else {
      resultsBox.innerHTML = "";
      resultsBox.classList.remove("active");
      input.value = "";
    }
  });

  input.addEventListener("input", function () {
    const query = input.value.trim();

    clearTimeout(debounceTimer);

    if (query.length < 1) {
      showPopularSearches();
      return;
    }

    debounceTimer = setTimeout(() => {
      fetch(`/search/suggest?q=${encodeURIComponent(query)}&resources[type]=product&resources[limit]=6&section_id=predictive-search`)
        .then((response) => response.text())
        .then((html) => {
          const parser = new DOMParser();
          const doc = parser.parseFromString(html, "text/html");
          const resultsMarkup = doc.querySelector("#shopify-section-predictive-search");

          if (resultsMarkup && resultsMarkup.innerHTML.trim() !== "") {
            resultsBox.innerHTML = resultsMarkup.innerHTML;
            resultsBox.classList.add("active");
          } else {
            resultsBox.innerHTML = '<div class="predictive-search-empty">No products found</div>';
            resultsBox.classList.add("active");
          }
        })
        .catch(() => {
          resultsBox.innerHTML = '<div class="predictive-search-empty">No products found</div>';
          resultsBox.classList.add("active");
        });
    }, 180);
  });

  document.addEventListener("click", function (event) {
    if (!event.target.closest(".header-search")) {
      searchWrapper.classList.remove("active");
      resultsBox.classList.remove("active");
    }
  });
});

document.addEventListener("DOMContentLoaded", function () {
  const root = document.querySelector("[data-page-predictive-search]");
  const input = root?.querySelector("[data-page-predictive-search-input]");
  const resultsBox = root?.querySelector("[data-page-predictive-search-results]");
  if (!root || !input || !resultsBox) return;

  let debounceTimer;
  let latestQuery = "";

  function hideResults() {
    resultsBox.hidden = true;
    resultsBox.classList.remove("active");
    resultsBox.innerHTML = "";
    input.setAttribute("aria-expanded", "false");
  }

  function showResults(html) {
    resultsBox.innerHTML = html;
    resultsBox.hidden = false;
    resultsBox.classList.add("active");
    input.setAttribute("aria-expanded", "true");
  }

  function fetchSearchSuggestions() {
    const query = input.value.trim();
    window.clearTimeout(debounceTimer);

    if (!query) {
      hideResults();
      return;
    }

    debounceTimer = window.setTimeout(() => {
      latestQuery = query;
      fetch(`/search/suggest?q=${encodeURIComponent(query)}&resources[type]=product&resources[limit]=6&section_id=predictive-search`)
        .then((response) => {
          if (!response.ok) throw new Error("Predictive search failed");
          return response.text();
        })
        .then((html) => {
          if (input.value.trim() !== latestQuery) return;
          const parser = new DOMParser();
          const doc = parser.parseFromString(html, "text/html");
          const resultsMarkup = doc.querySelector("#shopify-section-predictive-search");

          if (resultsMarkup && resultsMarkup.innerHTML.trim() !== "") {
            showResults(resultsMarkup.innerHTML);
          } else {
            showResults('<div class="predictive-search-empty">No products found</div>');
          }
        })
        .catch(() => {
          showResults('<div class="predictive-search-empty">No products found</div>');
        });
    }, 160);
  }

  input.addEventListener("input", fetchSearchSuggestions);
  input.addEventListener("focus", fetchSearchSuggestions);
  input.addEventListener("keydown", (event) => {
    if (event.key === "Escape") hideResults();
  });

  document.addEventListener("click", (event) => {
    if (!root.contains(event.target)) hideResults();
  });
});
